package com.app.service;

import com.amazonaws.services.s3.AmazonS3;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@Service
public class BucketService {
    @Autowired
    private AmazonS3 amazonS3;

    public String uploadFile(MultipartFile file, String bucketName) {
        if (file.isEmpty()) {
            throw new IllegalStateException("Cannot upload an empty file.");
        }

        File convFile = new File(System.getProperty("java.io.tmpdir") + "/" + file.getOriginalFilename());

        try {
            // Convert MultipartFile to File
            file.transferTo(convFile);

            // Upload to S3
            amazonS3.putObject(bucketName, convFile.getName(), convFile);

            // Get the file URL and return it
            return amazonS3.getUrl(bucketName, file.getOriginalFilename()).toString();
        } catch (IOException e) {
            throw new IllegalStateException("Failed to upload file to S3", e);
        }
        }
    }

/*
//SIR KA CODE AUR THORE BAKI HAI................
UPPAR WLA CHATGPT KA HAI..........................


package com.app.service;

import com.amazonaws.services.s3.AmazonS3;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;

@Service
public class BucketService {
@Autowired
    private AmazonS3 amazonS3;
    public String uploadFile(MultipartFile file,String bucketName){
        if(file.isEmpty()){
            throw new IllegalStateException("Cannot upload empty");
        }
        try{
            File convFile=new File(System.getProperty("java.io.tmpdir") +"/" file.getOriginalFilename());
            file.transferTo(convFile);
            try{
                amazonS3.putObject(bucketName,convFile.getName(),convFile);
                return amazonS3.getUrl(bucketName ,file.getOriginalFilename())
            }
        }

    }
}


 */