package com.app.repository;

import com.app.entity.carEvaluation.Agent;
import com.app.entity.carEvaluation.Area;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AreaRepository extends JpaRepository<Area, Long> {


 List<Area>findByPinCode(String pinCode);

}