package com.app.controller;

import com.app.entity.carEvaluation.Agent;
import com.app.entity.carEvaluation.Area;
import com.app.entity.carEvaluation.CustomerVisit;
import com.app.repository.AgentRepository;
import com.app.repository.AreaRepository;


import com.app.repository.CustomerVisitRepository;
import com.app.service.TwilioService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/crm")
public class CRMController {
    private AreaRepository areaRepository;
    private AgentRepository agentRepository;
    private CustomerVisitRepository customerVisitRepository;
    private TwilioService twilioService;

    public CRMController(AreaRepository areaRepository,AgentRepository agentRepository,CustomerVisitRepository customerVisitRepository
    ,TwilioService twilioService){
        this.areaRepository=areaRepository;
        this.agentRepository=agentRepository;
        this.customerVisitRepository=customerVisitRepository;
        this.twilioService=twilioService;
    }
    @GetMapping
    public ResponseEntity<List<Area>>searchAgent(
           @RequestParam String pinCode
    ){
      List<Area> areas= areaRepository.findByPinCode(pinCode);
        return new ResponseEntity<>(areas, HttpStatus.OK);
    }
    @PutMapping
    public String allocateAgent(
            @RequestParam  long customerId ,
            @RequestParam long agentId
    ){
        Agent agent=null;
 Optional<Agent> opAgent =agentRepository.findById(agentId);

if(opAgent.isPresent()){
  agent=opAgent.get();
}
Optional <CustomerVisit> optionalCustomerVisit=customerVisitRepository.findById(customerId);
CustomerVisit customerVisit=optionalCustomerVisit.get();
customerVisit.setAgent(agent);
customerVisitRepository.save(customerVisit);

//SMS
      twilioService.sendSms("+9162032154987","Agent is now Allocated-1234567890");
return "Agent is now allocated";
    }

}
