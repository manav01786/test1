package com.app.entity.carEvaluation;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "actual_car_details_evaluation")
public class ActualCarDetailsEvaluation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "kms",nullable = false)
    private Integer kms;

    @Column(name = "year_of_manufacturing",nullable = false)
    private Integer yearOfManufacturing;

}