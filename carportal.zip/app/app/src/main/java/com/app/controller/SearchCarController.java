package com.app.controller;

import com.app.entity.cars.Brand;
import com.app.entity.cars.Car;
import com.app.repository.BrandRepository;
import com.app.repository.CarRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/search-car")
public class SearchCarController {
    private BrandRepository brandRepository;
    private CarRepository carRepository;

    public SearchCarController(BrandRepository brandRepository,CarRepository carRepository){
        this.brandRepository=brandRepository;
        this.carRepository=carRepository;
    }

    //http://localhost:8080/search-car/cars?brand=honda
    @GetMapping("/cars")
    public List<Car>searchCars(@RequestParam  String brand){

     return   carRepository.searchCar(brand);
    }
}
