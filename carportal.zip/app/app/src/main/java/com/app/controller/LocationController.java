package com.app.controller;

import com.app.service.GeolocationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/location")
public class LocationController {

    private final GeolocationService geolocationService;

    public LocationController(GeolocationService geolocationService) {
        this.geolocationService = geolocationService;
    }

    @GetMapping("/get-location")
    public ResponseEntity<String> getLocation(HttpServletRequest request) {
        String ipAddress = extractClientIp(request); // Extracts real client IP
        String locationData = geolocationService.getLocation("103.5.135.44");
        return ResponseEntity.ok(locationData);
    }

    private String extractClientIp(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        return (ip != null && !ip.isEmpty()) ? ip.split(",")[0] : request.getRemoteAddr();
    }
}



