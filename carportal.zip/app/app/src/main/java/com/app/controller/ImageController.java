package com.app.controller;

import com.app.entity.cars.Car;
import com.app.entity.cars.CarImage;
import com.app.playload.ImageDto;
import com.app.repository.CarImageRepository;
import com.app.repository.CarRepository;
import com.app.service.BucketService;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Optional;

import static org.springframework.http.ResponseEntity.ok;

@RestController
@RequestMapping("/img")
public class ImageController {
    private BucketService bucketService;
    private CarRepository carRepository;
    private CarImageRepository carImageRepository;

    public ImageController (BucketService bucketService,CarRepository carRepository,CarImageRepository carImageRepository){
        this.bucketService=bucketService;
        this.carRepository=carRepository;
        this.carImageRepository=carImageRepository;
    }
    @PostMapping(path="/upload/file/{bucketName}/car/{carId}")
    public ResponseEntity<CarImage> uploadCarPhoto(@RequestParam MultipartFile file,
                                                   @PathVariable String bucketName,
                                                   @PathVariable long carId){
 String url=bucketService.uploadFile(file,bucketName);

// ImageDto imageDto=new ImageDto();
// imageDto.setImageUrl(url);
        Car car =carRepository.findById(carId).get();

        CarImage image=new CarImage();
        image.setUrl(url);
        image.setCar(car);
       CarImage savedImage=carImageRepository.save(image);
return new ResponseEntity<>(savedImage, HttpStatus.OK);
    }
}
